package com.monocept.entity;

public enum Role {
	ADMIN,STAFF

}
