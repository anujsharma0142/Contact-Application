package com.monocept.entity;

public enum NEType {
	
	NUMBER,EMAIL

}
